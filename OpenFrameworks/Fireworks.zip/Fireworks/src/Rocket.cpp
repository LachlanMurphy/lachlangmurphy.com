#pragma once

#ifndef _Rocket
#define _Rocket

#include "ofMain.h"

class Rocket {
public:
	ofVec2f pos;
	ofVec2f vel = ofVec2f(ofRandom(-2,2), -ofRandom(5, 10));
	

	int life = ofRandom(75,100);

	Rocket() {
		pos.set(ofRandom(ofGetWidth()), ofGetHeight() + 100);
	}

	void display() {
		pos += vel;
		life--;
		
		ofSetColor(255);
		ofDrawCircle(pos.x + 5*cos(life), pos.y + 5*sin(life), 10);
		
	}
};

#endif // !_Rocket
