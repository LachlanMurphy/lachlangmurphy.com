#ifndef _Particle
#define _Particle

#include "ofMain.h"
#include <cmath>

class Particle {
public:
	ofVec2f pos;
	ofVec2f vel;
	int life;
	int maxLife;
	ofColor col;

	Particle(ofVec2f org, int l) {
		pos = org;
		float a = (float)ofRandom(M_TWO_PI);
		vel.set(cos(a), sin(a));
		vel *= (int)ofRandom(15,25);
		life = l;
		maxLife = l;
		col = ofColor((int)ofRandom(255), (int)ofRandom(255), (int)ofRandom(255));
	}

	void display() {
		pos += vel;
		vel *= 0.95;
		vel.y += 0.5;
		ofSetColor(col, ofMap(life, 0, maxLife, 0, 255));
		ofDrawCircle(pos.x, pos.y, 5);
		life--;
	}
};
#endif // !_Particle
