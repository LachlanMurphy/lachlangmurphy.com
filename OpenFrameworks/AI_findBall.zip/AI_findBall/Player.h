#pragma once

#ifndef _Player
#define _Player

#include "ofMain.h"

class Player {
public:
	ofVec2f pos = ofVec2f(ofGetWidth() / 2, ofGetHeight() / 2);
	const int R = 10;
	const int STEP = 10;
	int score = std::numeric_limits<int>::max();
	bool alive = true;
	int genePos = 0;

	vector<int> gene;

	Player();
	Player(vector<int> newGene, bool goalReached); // Used for mutation, makes a copy of parent player
	Player(vector<int> newGene, bool goalReached, bool t); // Used for mutation, mutates the gene to change it

	void step();
	void display();
	void calcScore(ofVec2f g);
};
#endif // !_Player
