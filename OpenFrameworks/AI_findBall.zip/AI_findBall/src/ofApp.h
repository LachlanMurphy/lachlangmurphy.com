#pragma once

#include "ofMain.h"
#include "../Player.h"

class ofApp : public ofBaseApp{

	public:
		void mutate();
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);

		vector<Player> players;
		ofVec2f goal;
		
		bool goalReached = false;
		int numGens = 0;
		int minScore = 100;
		
		bool noLoop = false;
};