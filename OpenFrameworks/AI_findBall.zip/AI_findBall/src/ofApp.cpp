#include "ofApp.h"

void ofApp::mutate() {
	numGens++;
	for (int i = 0; i < players.size(); i++) {
		players[i].calcScore(goal);
	}
	
	int lowScore = std::numeric_limits<int>::max();
	vector<int> newGene = players[0].gene;
	
	for (int i = 1; i < players.size(); i++) {
		if (players[i].score < lowScore) {
			newGene = players[i].gene;
			lowScore = players[i].score;
		}
	}

	minScore = lowScore;
	int playerSize = players.size();
	players.clear();
	players.shrink_to_fit();
	
	players.push_back(Player(newGene, goalReached));
	for (int i = 1; i < playerSize; i++) {
		players.push_back(Player(newGene, goalReached, true));
	}
	cout << "Generation: " << numGens << " :: Min Score: " << minScore << endl;

	if (goalReached) {
		noLoop = true;
	}
}

//--------------------------------------------------------------
void ofApp::setup(){

	for (int i = 0; i < 10; i++)
		players.push_back(Player());

	goal = ofVec2f(60, 60);
}

//--------------------------------------------------------------
void ofApp::update(){

}

//--------------------------------------------------------------
void ofApp::draw(){

	int numAlive = 0;
	for (int i = 0; i < players.size(); i++) {
		if (players[i].alive) {
			numAlive++;
			players[i].step();
			players[i].display();
			if (players[i].pos.distance(goal) < players[i].R + 10) {
				
				mutate();
				goalReached = true;
			}
		}
	}
	if (numAlive == 0) mutate();

	ofSetColor(255, 0, 0);
	ofDrawCircle(goal.x, goal.y, 10);
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
