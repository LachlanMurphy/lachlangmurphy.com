#include "Player.h"

Player::Player() {
	for (int i = 0; i < 100; i++) {
		gene.push_back((int)ofRandom(4));
	}
}

Player::Player(vector<int> newGene, bool goalReached) {
	gene = newGene;
	if (!goalReached) {
		for (int i = 0; i < 50; i++) {
			gene.push_back((int)ofRandom(4));
		}
	}
}

Player::Player(vector<int> newGene, bool goalReached, bool t) {
	for (int i = 0; i < newGene.size(); i++) {
		if (ofRandom(1) < 0.1) {
			gene.push_back((int)ofRandom(4));
		}
		else {
			gene.push_back(newGene[i]);
		}
	}
	if (!goalReached) {
		for (int i = 0; i < 50; i++) {
			gene.push_back((int)ofRandom(4));
		}
	}
}

void Player::step() {

	if (genePos >= gene.size()) {
		alive = false;
		return;
	}

	switch (gene[genePos]) {
	case 0:
		pos.x += STEP;
		break;
	case 1:
		pos.x -= STEP;
		break;
	case 2:
		pos.y += STEP;
		break;
	case 3:
		pos.y -= STEP;
		break;
	}

	genePos++;
}

void Player::display() {
	ofSetColor(255);
	ofDrawCircle(pos.x, pos.y, R);
}

void Player::calcScore(ofVec2f g) {
	if (pos.distance(g) < R + 10) {
		score = genePos;
	}
	else {
		score = pos.distance(g) * genePos;
	}
}